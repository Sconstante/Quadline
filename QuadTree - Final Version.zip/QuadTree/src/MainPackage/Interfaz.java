package MainPackage;

import java.awt.Color;
import javax.swing.JFrame;


public class Interfaz extends JFrame {

    public final int FrameWidth = 800;
    public final int FrameHeight = 600;

    public GraphicEngine g;

    public static void main(String[] args) {
        Interfaz i = new Interfaz();
    }

    public Interfaz() {

       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setResizable(false);
        pack();
        g = new GraphicEngine(this);
        add(g.WorkBoard);
        setSize( FrameWidth, FrameHeight);//800,600
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(35, 37, 43));
        setVisible(true);

        int xx = ( FrameWidth + ( FrameWidth - getContentPane().getWidth()));
        int yy = (FrameHeight + (FrameHeight - getContentPane().getHeight()));
        setSize(xx, yy);
    }
}
