package MainPackage;

import GraphicObjects.Point;
import GraphicObjects.Quad;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class GraphicEngine extends java.awt.Canvas implements Runnable {
    //ANCHO:584 ALTO:492

    public static Thread GameLoop;
    public static boolean workingLoop = false;

    public static Interfaz Window;

    public static int aps = 0;
    public static int fps = 0;
    private static BufferedImage imagen;

    private static int[] pixeles;

    public int[] pixelex;
    //public static teclado tecla;

    public final int WorkBoardWidth = 513;
    public final int WorlkBoardHeight = 513;

    public static JPanel WorkBoard;
    public boolean Clicked;
    public boolean beforeClicked;
    public static Mouse mouse;

    public static ArrayList<Point> Points = new ArrayList<Point>();
    public static Quad MainQuad;

    public GraphicEngine(Interfaz w) {

        Window = w;
        WorkBoard = new JPanel();
        WorkBoard.setBounds(142, 15, WorkBoardWidth, WorlkBoardHeight + 5);
        WorkBoard.setBackground(new Color(35, 37, 43)/*Window.getContentPane().getBackground()*/);
        WorkBoard.add(this, BorderLayout.NORTH);
        WorkBoard.setVisible(true);

        mouse = new Mouse();
        addMouseListener(mouse);
        Clicked = false;
        beforeClicked = false;
        imagen = new BufferedImage(WorkBoardWidth, WorlkBoardHeight, BufferedImage.TYPE_INT_RGB);
        pixeles = ((DataBufferInt) imagen.getRaster().getDataBuffer()).getData();
        setPreferredSize(new Dimension(WorkBoardWidth, WorlkBoardHeight));
        pixelex = new int[WorkBoardWidth * WorlkBoardHeight];

        MainQuad = new Quad(0, 0, 512, 512);
        /*MainQuad.Q1 = new Quad(MainQuad.x, MainQuad.y, MainQuad.w / 2, MainQuad.h / 2);
        MainQuad.Q2 = new Quad(MainQuad.x + MainQuad.w / 2, MainQuad.y, MainQuad.h / 2, MainQuad.w / 2);
        MainQuad.Q3 = new Quad(MainQuad.x, MainQuad.y + MainQuad.h / 2, MainQuad.h / 2, MainQuad.w / 2);
        MainQuad.Q4 = new Quad(MainQuad.x + MainQuad.w / 2, MainQuad.y + MainQuad.h / 2, MainQuad.h / 2, MainQuad.w / 2);*/
        // p1 = new Point(10, 10, "a");
        StartLoop();
    }

    public void Actualizations() {//Here is where should be stay all changes or actions editing the pixel array
        mouse.UpdateCursor();
        Clicked = mouse.getPress();

        if (/*beforeClicked == false &&*/Clicked == true) {
            addPoint(mouse.x, mouse.y - 5);
        }
        //if (Points.size() > 1) {
            MainQuad.Actualizations();
        //}

        beforeClicked = Clicked;
    }

    public void addPoint(int x, int y) {

        boolean exist = false;

        for (int i = 0; i < Points.size(); i++) {
            if (Points.get(i).x == x && Points.get(i).y == y) {
                exist = true;
                break;
            }
        }
        if (exist == false) {
            Point newPoint = new Point(x, y);
            Points.add(newPoint);
        }
    }

    private void Frames() {// Here is where the pixel array shows what it have, it depend of the size of the screen 
        BufferStrategy estrategia = getBufferStrategy();
        Limpiar();

        if (estrategia == null) {
            createBufferStrategy(3);
            return;
        }

        System.arraycopy(pixelex, 0, pixeles, 0, pixeles.length);
        Graphics g = estrategia.getDrawGraphics();

        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), null);
        for (int i = 0; i < Points.size(); i++) {
            g = Points.get(i).Frames(g);
        }
        //g = MainQuad.Frames(g);
        g = MainQuad.Frames(g);
        g.dispose();
        estrategia.show();
    }

    public void Limpiar() {
        for (int j = 0; j < pixelex.length; j++) {
            pixelex[j] = 0xff4A6161;
        }
    }

    public void StartLoop() {
        Limpiar();
        GameLoop = new Thread(this, "Graficos");
        workingLoop = true;
        GameLoop.start();
    }

    public void PauseLoop() {
        workingLoop = false;
        try {
            GameLoop.join();
        } catch (InterruptedException ex) {
            System.err.println("The Thread could not be paused");
        }
    }

    @Override
    public void run() {

        final int NS_SEG = 1000000000;
        final byte APS_OBJ = 10;
        final double NS_ACT = NS_SEG / APS_OBJ;
        long refact = System.nanoTime();
        long refcont = System.nanoTime();
        double time_trans;
        double delta = 0;
        while (workingLoop == true) {

            final long inibucle = System.nanoTime();
            time_trans = inibucle - refact;
            refact = inibucle;
            delta += time_trans / NS_ACT;
            while (delta >= 1) {

                Frames();
                aps++;
                delta--;
            }

            Actualizations();
            //Window.setTitle("Point In Memory: " + Points.size());
            fps++;
            if (System.nanoTime() - refcont > NS_SEG) {
                // Window.setTitle("Game Name" + " | APS: " + aps + " | FPS: " + fps);
                aps = 0;
                fps = 0;
                refcont = System.nanoTime();
            }

        }
    }

    public class Mouse extends MouseAdapter {

        public int x;
        public int y;
        private boolean click;
        private boolean press;
        public boolean release;

        public Mouse() {

        }

        public void UpdateCursor() {
            java.awt.Point pos = MouseInfo.getPointerInfo().getLocation();
            SwingUtilities.convertPointFromScreen(pos, WorkBoard);
            this.x = pos.x;
            this.y = pos.y;
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            if (click == false) {
                click = true;
            }
        }

        public boolean getClick() {
            return click;
        }
        public int tipoClick = 0;

        public void resetClick() {
            ////System.out.println(release);
            release = false;
            if (sw == 1) {
                release = true;
                sw = 2;
            }

            if (click == true) {
                click = false;
            }
            if (press == false && sw == 0) {
                sw = 1;
            }
        }
        private int sw = 2;

        @Override
        public void mouseReleased(MouseEvent e) {
            if (press == true) {
                press = false;
            }

        }

        @Override
        public void mousePressed(MouseEvent e) {
            if (press == false) {
                press = true;
            }
            sw = 0;

        }

        public boolean getPress() {
            return press;
        }

        public void resetPress() {
            if (press == true) {
                press = false;
            }
        }

    }

}
