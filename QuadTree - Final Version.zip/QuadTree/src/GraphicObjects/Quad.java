package GraphicObjects;

import MainPackage.GraphicEngine;
import java.awt.Color;
import java.awt.Graphics;

public class Quad {

    public final int x;
    public final int y;
    public final int h;
    public final int w;

    public Quad Q1;
    public Quad Q2;
    public Quad Q3;
    public Quad Q4;

    public Quad(int x, int y, int h, int w) {

        this.x = x;
        this.y = y;
        this.h = h;
        this.w = w;
        Q1 = null;
        Q2 = null;
        Q3 = null;
        Q4 = null;

        /*if (w > 2) {
            Q1 = new Quad(this.x, this.y, this.h / 2, this.w / 2);
        }*/
        //Q2 = new Quad(x + 256, y, h / 2, w / 2);
        //Q3 = new Quad(x, y + 256, h / 2, w / 2);
        //Q4 = new Quad(x + 256, y + 256, h / 2, w / 2);
    }

    public Graphics Frames(Graphics g) {

        g.setColor(Color.DARK_GRAY);
        g.drawRect(x, y, h, w);

        if (Q1 != null) {
            g = Q1.Frames(g);
        }
        if (Q2 != null) {
            g = Q2.Frames(g);
        }
        if (Q3 != null) {
            g = Q3.Frames(g);
        }
        if (Q4 != null) {
            g = Q4.Frames(g);
        }

        return g;
    }

    public void Actualizations() {

        int qq1 = 0, qq2 = 0, qq3 = 0, qq4 = 0;

        for (int i = 0; i < GraphicEngine.Points.size(); i++) {

            if (GraphicEngine.Points.get(i).x > this.x && GraphicEngine.Points.get(i).x < this.x + this.w / 2 && GraphicEngine.Points.get(i).y > this.y && GraphicEngine.Points.get(i).y < this.y + this.h / 2) {
                qq1++;
            }
            if (GraphicEngine.Points.get(i).x > this.x + this.w / 2 && GraphicEngine.Points.get(i).x < this.x + this.w && GraphicEngine.Points.get(i).y > this.y && GraphicEngine.Points.get(i).y < this.y + this.h / 2) {
                qq2++;
            }
            if (GraphicEngine.Points.get(i).x > this.x && GraphicEngine.Points.get(i).x < this.x + this.w / 2 && GraphicEngine.Points.get(i).y > this.y + this.h / 2 && GraphicEngine.Points.get(i).y < this.y + this.h) {
                qq3++;
            }
            if (GraphicEngine.Points.get(i).x > this.x + this.w / 2 && GraphicEngine.Points.get(i).x < this.x + this.w && GraphicEngine.Points.get(i).y > this.y + this.h / 2 && GraphicEngine.Points.get(i).y < this.y + this.h) {
                qq4++;
            }

        }
        //GraphicEngine.Window.setTitle(qq1 + "/" + qq2 + "/" + qq3 + "/" + qq4);
        if (Q1 != null && qq1 > 1) {
            Q1.Actualizations();
        }
        if (Q2 != null && qq2 > 1) {
            Q2.Actualizations();
        }
        if (Q3 != null && qq3 > 1) {
            Q3.Actualizations();
        }
        if (Q4 != null && qq4 > 1) {
            Q4.Actualizations();
        }

        if (Q1 == null && qq1 > 0) {
            Q1 = new Quad(this.x, this.y, this.w / 2, this.h / 2);
            Q2 = new Quad(this.x + this.w / 2, this.y, this.h / 2, this.w / 2);
            Q3 = new Quad(this.x, this.y + this.h / 2, this.h / 2, this.w / 2);
            Q4 = new Quad(this.x + this.w / 2, this.y + this.h / 2, this.h / 2, this.w / 2);
        }
        if (Q2 == null && qq2 > 0) {
            Q1 = new Quad(this.x, this.y, this.w / 2, this.h / 2);
            Q2 = new Quad(this.x + this.w / 2, this.y, this.h / 2, this.w / 2);
            Q3 = new Quad(this.x, this.y + this.h / 2, this.h / 2, this.w / 2);
            Q4 = new Quad(this.x + this.w / 2, this.y + this.h / 2, this.h / 2, this.w / 2);
        }
        if (Q3 == null && qq3 > 0) {
            Q1 = new Quad(this.x, this.y, this.w / 2, this.h / 2);
            Q2 = new Quad(this.x + this.w / 2, this.y, this.h / 2, this.w / 2);
            Q3 = new Quad(this.x, this.y + this.h / 2, this.h / 2, this.w / 2);
            Q4 = new Quad(this.x + this.w / 2, this.y + this.h / 2, this.h / 2, this.w / 2);
        }
        if (Q4 == null && qq4 > 0) {
            Q1 = new Quad(this.x, this.y, this.w / 2, this.h / 2);
            Q2 = new Quad(this.x + this.w / 2, this.y, this.h / 2, this.w / 2);
            Q3 = new Quad(this.x, this.y + this.h / 2, this.h / 2, this.w / 2);
            Q4 = new Quad(this.x + this.w / 2, this.y + this.h / 2, this.h / 2, this.w / 2);
        }

    }

    public Graphics FramesMesh(Graphics g) {

        g.setColor(Color.RED);
        for (int i = 0; i < 128; i++) {
            g.drawRect(x + (i * 4), y + (i * 4), h - (i * 4), w - (i * 4));
            g.drawRect(x, y, (i * 4), (i * 4));
        }

        //g.drawRect(x + 4, y + 4, h - 1, w - 1);
        return g;
    }
}
