package GraphicObjects;

import java.awt.Color;
import java.awt.Graphics;

public class Point {

    public final int x;
    public final int y;

    public Point(int x, int y) {

        this.x = x;
        this.y = y;
    }

    public Graphics Frames(Graphics g) {

        /*g.setColor(Color.GRAY);
        g.drawRect(x-1, y-1, 2, 2);*/
        g.setColor(Color.BLACK);
        g.drawRect(x, y, 0, 0);
        g.drawOval(x-1, y-1, 2, 2);
        return g;
    }
}
